package com.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point of the Hospital Management System.
 * @SpringBootApplication is a combination of:
 *   - @Configuration
 *   - @EnableAutoConfiguration
 *   - @ComponentScan
 * So Spring automatically scans all classes inside com.hospital package
 * (controller, service, serviceimpl, repository, entity, config).
 */
@SpringBootApplication
public class HospitalApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalApplication.class, args);
    }
}
