package com.hospital.service;

import com.hospital.entity.Patient;

import java.util.List;

public interface PatientService {
    Patient addPatient(Patient patient);
    List<Patient> getAllPatients();
    List<Patient> searchPatientsByName(String name);
    Patient getPatientById(Integer id);
    Patient updatePatient(Patient patient);
    void deletePatient(Integer id);
}
