package com.hospital.service;

import com.hospital.entity.Doctor;

import java.util.List;

public interface DoctorService {
    Doctor addDoctor(Doctor doctor);
    List<Doctor> getAllDoctors();
    Doctor getDoctorById(Integer id);
    void deleteDoctor(Integer id);
}
