 package com.hospital.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * A simple @Configuration class.
 *
 * NOTE: @SpringBootApplication already includes @ComponentScan internally,
 * so this class is technically not required. It is added here only to
 * demonstrate how @Configuration and @ComponentScan work as basic
 * Spring annotations.
 */
@Configuration
@ComponentScan(basePackages = "com.hospital")
public class AppConfig {
    // No beans needed right now.
    // You can define custom @Bean methods here in the future if required.
}
