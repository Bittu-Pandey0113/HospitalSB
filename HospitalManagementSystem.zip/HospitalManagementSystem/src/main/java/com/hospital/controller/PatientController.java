package com.hospital.controller;

import com.hospital.entity.Patient;
import com.hospital.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    // Show Add Patient form
    @GetMapping("/add")
    public String showAddPatientForm(Model model) {
        model.addAttribute("patient", new Patient());
        return "patient/addPatient";
    }

    // Handle Add Patient form submission
    @PostMapping("/add")
    public String addPatient(@ModelAttribute Patient patient) {
        patientService.addPatient(patient);
        return "redirect:/patients/view";
    }

    // View list of all patients, with optional search by name (@RequestParam)
    @GetMapping("/view")
    public String viewPatients(@RequestParam(value = "name", required = false) String name, Model model) {
        if (name != null && !name.trim().isEmpty()) {
            model.addAttribute("patients", patientService.searchPatientsByName(name));
        } else {
            model.addAttribute("patients", patientService.getAllPatients());
        }
        return "patient/viewPatients";
    }

    // Show Edit Patient form (using @PathVariable to get patient id)
    @GetMapping("/edit/{id}")
    public String showEditPatientForm(@PathVariable Integer id, Model model) {
        model.addAttribute("patient", patientService.getPatientById(id));
        return "patient/editPatient";
    }

    // Handle Edit Patient form submission
    @PostMapping("/edit")
    public String updatePatient(@ModelAttribute Patient patient) {
        patientService.updatePatient(patient);
        return "redirect:/patients/view";
    }

    // Delete a patient by id
    @GetMapping("/delete/{id}")
    public String deletePatient(@PathVariable Integer id) {
        patientService.deletePatient(id);
        return "redirect:/patients/view";
    }
}
