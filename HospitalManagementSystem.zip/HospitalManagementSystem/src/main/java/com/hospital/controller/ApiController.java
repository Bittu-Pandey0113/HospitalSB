package com.hospital.controller;

import com.hospital.entity.Doctor;
import com.hospital.entity.Patient;
import com.hospital.service.DoctorService;
import com.hospital.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * A small REST API on top of the same services, just to demonstrate
 * @RestController, @RequestBody and @PathVariable working with JSON.
 * This is optional and not required by the Thymeleaf pages above.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private PatientService patientService;

    // GET http://localhost:8080/api/doctors/1
    @GetMapping("/doctors/{id}")
    public Doctor getDoctor(@PathVariable Integer id) {
        return doctorService.getDoctorById(id);
    }

    // POST http://localhost:8080/api/patients  (JSON body)
    @PostMapping("/patients")
    public Patient addPatientViaApi(@RequestBody Patient patient) {
        return patientService.addPatient(patient);
    }
}
