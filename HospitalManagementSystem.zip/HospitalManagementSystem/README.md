# Hospital Management System — Updated Run Instructions

## IMPORTANT: How to run this project in Eclipse

This is a **Spring Boot application** (Spring Boot 3.2.5). Do **not** run/deploy it by adding it to Eclipse's external Tomcat 11 server. The error `ClassNotFoundException: javax.servlet.http.HttpServlet` comes from the external Tomcat deployment configuration, not from the normal Spring Boot startup path. Spring Boot 3 uses `jakarta.servlet` and includes its own embedded Tomcat.

1. In Eclipse, stop the external Tomcat server.
2. In the **Servers** tab, if this project is listed under Tomcat, right-click the project and choose **Remove**. This does not delete your source files.
3. Right-click the project → **Maven → Update Project…** → select the project → **OK**.
4. Right-click the project → **Run As → Java Application** (or **Run As → Spring Boot App**, if available). Choose `com.hospital.HospitalApplication`.
5. Wait for the console message `Started HospitalApplication`.
6. Open `http://localhost:8080/`.

If port 8080 is already in use, stop the other server or change `server.port` in `src/main/resources/application.properties` to `8081`, then open `http://localhost:8081/`.

## PostgreSQL setup

Create the database used by this project's current configuration:

```sql
CREATE DATABASE hospitaldb;
```

In `src/main/resources/application.properties`, set `spring.datasource.username` and `spring.datasource.password` to your local PostgreSQL credentials. The provided password value is only an example; replace it if it does not match your setup.

If startup fails, read the **first ERROR** in the Eclipse Console. A PostgreSQL authentication/connection error means the database settings need fixing; the `javax.servlet` error means the app is still being deployed to the external Tomcat instead of run as a Spring Boot application.

---

A simple Hospital Management System built with **Spring Boot**, **Thymeleaf**, **Bootstrap 5**, and **PostgreSQL**.
This project intentionally uses only basic, beginner-friendly Spring annotations:

`@SpringBootApplication`, `@Configuration`, `@ComponentScan`, `@Component`, `@Autowired`,
`@Controller`, `@RestController`, `@RequestMapping`, `@GetMapping`, `@PostMapping`,
`@PathVariable`, `@RequestParam`, `@RequestBody`, `@ModelAttribute`,
`@Entity`, `@Id`, `@GeneratedValue`, `@Table`, `@ManyToOne`, `@JoinColumn`, `@Repository`.

## Tech Stack
- Backend: Spring Boot 3.2.5 (Java 17)
- Frontend: Thymeleaf + Bootstrap 5 (via CDN)
- Database: PostgreSQL
- ORM: Spring Data JPA (Hibernate)
- Build Tool: Maven

## Project Structure
```
com.hospital
├── controller       -> HomeController, DoctorController, PatientController, AppointmentController, ApiController
├── entity            -> Doctor, Patient, Appointment
├── repository        -> DoctorRepository, PatientRepository, AppointmentRepository
├── service            -> DoctorService, PatientService, AppointmentService (interfaces)
├── serviceimpl        -> DoctorServiceImpl, PatientServiceImpl, AppointmentServiceImpl
├── config             -> AppConfig (@Configuration / @ComponentScan demo)
└── HospitalApplication.java
```

## 1. Setup PostgreSQL Database

Create a database before running the app:

```sql
CREATE DATABASE hospital_db;
```

Update the credentials in `src/main/resources/application.properties` if needed:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/hospital_db
spring.datasource.username=postgres
spring.datasource.password=postgres
```

Hibernate is configured with `spring.jpa.hibernate.ddl-auto=update`, so the
`doctors`, `patients`, and `appointments` tables will be created automatically
the first time you run the app.

## 2. Run the Project

Using Maven wrapper / Maven:

```bash
mvn spring-boot:run
```

Or build a jar and run it:

```bash
mvn clean package
java -jar target/HospitalManagementSystem-1.0.0.jar
```

The app starts on **http://localhost:8080**

## 3. Pages / URLs

| Page                 | URL                          |
|-----------------------|-------------------------------|
| Home                  | `/`                            |
| Dashboard             | `/dashboard`                   |
| Add Doctor            | `/doctors/add`                 |
| View Doctors          | `/doctors/view`                |
| Delete Doctor         | `/doctors/delete/{id}`         |
| Add Patient           | `/patients/add`                |
| View / Search Patients| `/patients/view?name=...`      |
| Edit Patient          | `/patients/edit/{id}`          |
| Delete Patient        | `/patients/delete/{id}`        |
| Book Appointment      | `/appointments/add`            |
| View Appointments     | `/appointments/view`           |
| Cancel Appointment    | `/appointments/delete/{id}`    |

A tiny bonus REST API (uses `@RestController` + `@RequestBody`) is also included:

| Method | URL                | Description                    |
|--------|---------------------|--------------------------------|
| GET    | `/api/doctors/{id}` | Get a doctor as JSON           |
| POST   | `/api/patients`     | Add a patient by sending JSON  |

## Notes
- All form pages use plain Thymeleaf forms (`th:object`, `th:field`) — no JavaScript frameworks.
- Field injection with `@Autowired` is used everywhere for simplicity (fine for a learning project).
- `AppConfig` (`@Configuration` + `@ComponentScan`) is included only to demonstrate the annotations;
  it's technically redundant because `@SpringBootApplication` already scans the `com.hospital` package.
